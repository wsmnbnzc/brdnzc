#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/12/18 11:58
# @Author  : Jackie
# @File    : googleRegister.py

import sys

reload(sys)
sys.setdefaultencoding('utf8')
import time
import os
import requests
import logging
import json
import random
import re
import uuid
import base64
import datetime
import logging.handlers
from bs4 import BeautifulSoup
from threading import Thread, Lock
from selenium import webdriver
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support import expected_conditions as EC
import ConfigParser
from pynamesgenerator import pynamesgenerator

seed = 'abcdefghijklmnopqrstuvwxyz'
seed2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
seed3 = '1234567890'

user = 'gnm12138'
password = '181219col'
apiname = 'api-192529-rcEjZrm'
maillist = ['yahoo.com', 'hotmail.com', 'mail.com', 'outlook.com', 'co.jp', 'yahoo.jp', 'aol.com', 'gmx.com']

#proxies = []
#f = open('./proxy.txt', 'r')
#for line in f.readlines():
#    proxies.append(line.strip())
#f.close()

LOG = None

def initlog():
    logger = logging.getLogger()
    LOG_FILE = './log.txt'
    hdlr = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1024 * 1024 * 200, backupCount=20)
    formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)
    logger.setLevel(logging.NOTSET)
    return logger

def randomAgentGen():
    userAgent = ['Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/7.0.5 Safari/537.77.4',
                'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.76.4 (KHTML, like Gecko) Version/7.0.4 Safari/537.76.4',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.78.2 (KHTML, like Gecko) Version/7.0.6 Safari/537.78.2',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10) AppleWebKit/538.46 (KHTML, like Gecko) Version/8.0 Safari/538.46',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.59.10 (KHTML, like Gecko) Version/5.1.9 Safari/534.59.10',
                'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',
                'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/34.0.1847.116 Chrome/34.0.1847.116 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.77.4 (KHTML, like Gecko) Version/6.1.5 Safari/537.77.4',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/537.75.14',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.74.9 (KHTML, like Gecko) Version/7.0.2 Safari/537.74.9',
                'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/537.75.14',
                'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36',
                'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.114 Safari/537.36',
                'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/36.0.1985.125 Chrome/36.0.1985.125 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10) AppleWebKit/600.1.3 (KHTML, like Gecko) Version/8.0 Safari/600.1.3',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36']
    UA = random.choice(userAgent)
    return UA

def login():
    r = requests.get('http://huoyun888.cn/api/do.php' + '?action=loginIn&name=' + apiname + '&password=' + password)
    if r.text.split('|')[0] == '1':
        token = r.text.split('|')[1]
        return token

def getnumber(token):
    while True:
        r = requests.get('http://huoyun888.cn/api/do.php' + '?action=getPhone&sid=1489&token=' + token)
        if r.text.split('|')[0] == '1':
            phonenumber = r.text.split('|')[1]
            return phonenumber
        else:
            time.sleep(3)
            continue

def getcode(token, phone):
    times = 0
    while True:
        r = requests.get('http://huoyun888.cn/api/do.php' + '?action=getMessage&sid=1489&phone=' + phone + '&token=' + token)
        if r.text.split('|')[0] == '1':
            code = r.text.split('|')[1]
            return code
        else:
            if times > 20:
                release(token, phone)
                return ''
            time.sleep(3)
            times += 1
            continue

def addblacklist(token, phone):
    while True:
        r = requests.get('http://huoyun888.cn/api/do.php' + '?action=addBlacklist&sid=1489&phone=' + phone + '&token=' + token)
        if r.text.split('|')[0] == '1':
            return
        else:
            time.sleep(3)
            continue
            
def release(token, phone):
    while True:
        r = requests.get('http://huoyun888.cn/api/do.php' + '?action=cancelRecv&sid=1489&phone=' + phone + '&token=' + token)
        if r.text.split('|')[0] == '1':
            return
        else:
            time.sleep(3)
            continue

def register(token):
    while True:
        number = ''
        code = ''
        try:
            #phone = str(random.choice(areas)) + "".join([str(random.randint(0, 9)) for _ in range(7)])
            pynamesgeneratorObject = pynamesgenerator()
            driver = None
            sex = pynamesgeneratorObject.gen_sex()
            if sex == 'male':
                username = pynamesgeneratorObject.gen_two_words(split=' ', lowercase=False, chinese=False, male=True)
                firstName = username.split(' ')[0]
                lastName = username.split(' ')[1]
                birthday = pynamesgeneratorObject.gen_year(1960, 2000) + '-' + pynamesgeneratorObject.gen_birthday()
                email = firstName + birthday.replace('-', '')
                secondemail = pynamesgeneratorObject.gen_one_gender_word(male=False) + pynamesgeneratorObject.gen_year(1960, 2000) + pynamesgeneratorObject.gen_birthday().replace('-', '') + '@' + random.choice(maillist)
                passwd = "".join(random.sample(seed2, 5))
                passwd += "".join(random.sample(seed, 5))
                passwd += "".join(random.sample(seed3, 2))
            else:
                username = pynamesgeneratorObject.gen_two_words(split=' ', lowercase=False, chinese=False, male=False)
                firstName = username.split(' ')[0]
                lastName = username.split(' ')[1]
                birthday = pynamesgeneratorObject.gen_year(1960, 2000) + '-' + pynamesgeneratorObject.gen_birthday()
                email = firstName + birthday.replace('-', '')
                secondemail = pynamesgeneratorObject.gen_one_gender_word(male=False) + pynamesgeneratorObject.gen_year(1960, 2000) + pynamesgeneratorObject.gen_birthday().replace('-', '') + '@' + random.choice(maillist)
                passwd = "".join(random.sample(seed2, 5))
                passwd += "".join(random.sample(seed, 5))
                passwd += "".join(random.sample(seed3, 2))
            LOG.info('begin:' + sex + ' ' + username + ' ' + firstName + ' ' + lastName + ' ' + birthday + ' ' + email + ' ' + secondemail + ' ' + passwd)
        
            target = 'https://accounts.google.com/signup'
            #options = webdriver.ChromeOptions()
            #Uagent = 'user-agent=' + randomAgentGen()
            #print Uagent
            #proxy = '--proxy-server=' + random.choice(proxies)
            #print proxy
            #options.add_argument(Uagent)
            #options.add_argument(proxy)
            #options.add_argument('--incognito')
            #options.add_argument('--disable-javascript')

            #driver = webdriver.Chrome('C:\Program Files (x86)\Google\Chrome\Application\chromedriver.exe', chrome_options = options)
            driver = webdriver.PhantomJS('./phantomjs-2.1.1-linux-x86_64/bin/phantomjs')
            driver.set_page_load_timeout(60)
            driver.get(target)
        
            last_input = driver.find_element_by_id("lastName")
            ActionChains(driver).move_to_element(last_input).perform()
            ActionChains(driver).click(last_input).perform()
            last_input.clear()
            last_input.send_keys(lastName.decode('utf-8'))
        
            first_input = driver.find_element_by_id("firstName")
            ActionChains(driver).move_to_element(first_input).perform()
            ActionChains(driver).click(first_input).perform()
            first_input.clear()
            first_input.send_keys(firstName.decode('utf-8'))
            
            email_input = driver.find_element_by_id("username")
            ActionChains(driver).move_to_element(email_input).perform()
            ActionChains(driver).click(email_input).perform()
            email_input.clear()
            email_input.send_keys(email.decode('utf-8'))
            
            passwd_input = driver.find_element_by_name("Passwd")
            ActionChains(driver).move_to_element(passwd_input).perform()
            ActionChains(driver).click(passwd_input).perform()
            passwd_input.clear()
            passwd_input.send_keys(passwd.decode('utf-8'))
            
            confirm_input = driver.find_element_by_name("ConfirmPasswd")
            ActionChains(driver).move_to_element(confirm_input).perform()
            ActionChains(driver).click(confirm_input).perform()
            confirm_input.clear()
            confirm_input.send_keys(passwd.decode('utf-8'))
            
            next_button = driver.find_element_by_id("accountDetailsNext")
            ActionChains(driver).move_to_element(next_button).perform()
            ActionChains(driver).click(next_button).perform()
            time.sleep(10)

            area_select = driver.find_element_by_id("countryList")
            ActionChains(driver).move_to_element(area_select).perform()
            ActionChains(driver).click(area_select).perform()
            time.sleep(1)
            
            js = 'document.getElementsByClassName("OA0qNb")[0].querySelectorAll(\'div[data-value="cn"]\')[0].click();'
            driver.execute_script(js)
            time.sleep(1)

            number = getnumber(token)
            LOG.info('phone:' + number)
            phone_input = driver.find_element_by_id("phoneNumberId")
            ActionChains(driver).move_to_element(phone_input).perform()
            ActionChains(driver).click(phone_input).perform()
            phone_input.send_keys(number.decode('utf-8'))
            time.sleep(1)
            
            next_button = driver.find_element_by_id("gradsIdvPhoneNext")
            ActionChains(driver).move_to_element(next_button).perform()
            ActionChains(driver).click(next_button).perform()
            time.sleep(10)
            
            code_input = driver.find_element_by_id("code")
            code = getcode(token, number)
            code = code.split('-')[1][:6]
            LOG.info('code:' + code)
            ActionChains(driver).move_to_element(code_input).perform()
            ActionChains(driver).click(code_input).perform()
            code_input.send_keys(code.decode('utf-8'))
            time.sleep(1)
            
            next_button = driver.find_element_by_id("gradsIdvVerifyNext")
            ActionChains(driver).move_to_element(next_button).perform()
            ActionChains(driver).click(next_button).perform()
            time.sleep(10)
            
            secondemail_input = driver.find_elements_by_class_name("whsOnd")[1]
            ActionChains(driver).move_to_element(secondemail_input).perform()
            ActionChains(driver).click(secondemail_input).perform()
            secondemail_input.clear()
            secondemail_input.send_keys(secondemail.decode('utf-8'))
            
            year_input = driver.find_element_by_id("year")
            ActionChains(driver).move_to_element(year_input).perform()
            ActionChains(driver).click(year_input).perform()
            year_input.send_keys(birthday.split('-')[0].decode('utf-8'))
            time.sleep(0.5)

            mouth_input = Select(driver.find_element_by_id("month"))
            mouth_input.select_by_value(str(int(birthday.split('-')[1])).decode('utf-8'))
            
            day_input = driver.find_element_by_id("day")
            ActionChains(driver).move_to_element(day_input).perform()
            ActionChains(driver).click(day_input).perform()
            day_input.send_keys(birthday.split('-')[2].decode('utf-8'))
            
            sex_input = Select(driver.find_element_by_id("gender"))
            if sex == 'male':
                sex_input.select_by_value('1')
            else:
                sex_input.select_by_value('2')
            
            next_button = driver.find_element_by_id("personalDetailsNext")
            ActionChains(driver).move_to_element(next_button).perform()
            ActionChains(driver).click(next_button).perform()
            time.sleep(10)
            
            #jump_button = driver.find_element_by_id("phoneUsageNext")
            #ActionChains(driver).move_to_element(jump_button).perform()
            #ActionChains(driver).click(jump_button).perform()
            js = 'document.getElementsByClassName("uBOgn")[2].click();'
            driver.execute_script(js)
            time.sleep(10)
            
            #js = 'document.getElementsByClassName("eLUXld")[0].scrollTo(0, 5000);'
            #driver.execute_script(js)
            #time.sleep(1)
            
            next_button = driver.find_element_by_id("termsofserviceNext")
            ActionChains(driver).move_to_element(next_button).perform()
            ActionChains(driver).click(next_button).perform()
            time.sleep(10)

            LOG.info('success:' + email + '@gmail.com|' + passwd + '|' + number + '|' + secondemail)
            f = open('./result.txt', 'a+')
            f.write(email + '@gmail.com|' + passwd + '|' + number + '|' + secondemail + '\n')
            f.close()
            data = {'g': email + '@gmail.com|' + passwd + '|' + number + '|' + secondemail + '\n'}
            r = requests.post('http://23.cheapaaab.com/g.php', data=data)
            driver.close()
            driver.quit()
        except Exception, e:
            LOG.error(e)
            driver.close()
            driver.quit()
            if code == '' and number != '':
                addblacklist(token, number)
            continue

if __name__ == '__main__':
    LOG = initlog()
    token = login()
    register(token)
